package trabajo02;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrmT02 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtCorrectas;
	private JTextField txtErroneas;
	private JTextField txtBlanco;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmT02 frame = new FrmT02();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmT02() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 514, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("NOTA FINAL");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(205, 11, 86, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblCorrectas = new JLabel("Respuestas Correctas:");
		lblCorrectas.setBounds(10, 50, 196, 14);
		contentPane.add(lblCorrectas);
		
		txtCorrectas = new JTextField();
		txtCorrectas.setBounds(205, 47, 86, 20);
		contentPane.add(txtCorrectas);
		txtCorrectas.setColumns(10);
		
		JLabel lblErroneas = new JLabel("Respuestas Incorrectas:");
		lblErroneas.setBounds(10, 80, 196, 14);
		contentPane.add(lblErroneas);
		
		txtErroneas = new JTextField();
		txtErroneas.setBounds(205, 78, 86, 20);
		contentPane.add(txtErroneas);
		txtErroneas.setColumns(10);
		
		JLabel lblBlanco = new JLabel("Respuestas en Blanco:");
		lblBlanco.setBounds(10, 116, 196, 14);
		contentPane.add(lblBlanco);
		
		txtBlanco = new JTextField();
		txtBlanco.setBounds(205, 109, 86, 20);
		contentPane.add(txtBlanco);
		txtBlanco.setColumns(10);
		
		JLabel lblMensaje = new JLabel("Su Nota Final Es....");
		lblMensaje.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblMensaje.setBounds(120, 164, 229, 14);
		contentPane.add(lblMensaje);
		
		JButton btnProcesar = new JButton("PROCESAR");
		btnProcesar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int pc = Integer.parseInt(txtCorrectas.getText().toString());
				int pi = Integer.parseInt(txtErroneas.getText().toString());
				int pb = Integer.parseInt(txtBlanco.getText().toString());
				
				int puntaje = pc*5+pi*-1+pb*0;
				lblMensaje.setText( "Su No Final Es " + puntaje );
				
			}
		});
		btnProcesar.setBounds(344, 46, 117, 23);
		contentPane.add(btnProcesar);
	}

}
